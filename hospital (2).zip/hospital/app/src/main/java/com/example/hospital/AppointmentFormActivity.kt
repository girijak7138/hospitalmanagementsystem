package com.example.hospital

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class AppointmentFormActivity : AppCompatActivity() {

    private lateinit var nameEditText: EditText
    private lateinit var dobEditText: EditText
    private lateinit var genderRadioGroup: RadioGroup
    private lateinit var maleRadioButton: RadioButton
    private lateinit var femaleRadioButton: RadioButton
    private lateinit var mobileEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var appointmentDateEditText: EditText
    private lateinit var appointmentTimeEditText: EditText
    private lateinit var submitButton: Button
    private lateinit var backButton: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.appointment_form)

        nameEditText = findViewById(R.id.guestNameEditText)
        dobEditText = findViewById(R.id.guestDobEditText)
        genderRadioGroup = findViewById(R.id.guestGenderRadioGroup)
        maleRadioButton = findViewById(R.id.maleRadioButton)
        femaleRadioButton = findViewById(R.id.femaleRadioButton)
        mobileEditText = findViewById(R.id.guestMobileEditText)
        emailEditText = findViewById(R.id.guestEmailEditText)
        appointmentDateEditText = findViewById(R.id.guestAppointmentDateEditText)
        appointmentTimeEditText = findViewById(R.id.guestAppointmentTimeEditText)
        submitButton = findViewById(R.id.guestSubmitButton)
        backButton = findViewById(R.id.backButton)

        submitButton.setOnClickListener {
            handleSubmitButtonClick()
        }

        backButton.setOnClickListener {
            // Assuming successful login, navigate to HomeActivity
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }

    private fun handleSubmitButtonClick() {
        val name = nameEditText.text.toString()
        val dob = dobEditText.text.toString()
        val gender = if (maleRadioButton.isChecked) "Male" else "Female"
        val mobile = mobileEditText.text.toString()
        val email = emailEditText.text.toString()
        val appointmentDate = appointmentDateEditText.text.toString()
        val appointmentTime = appointmentTimeEditText.text.toString()

        val databaseHelper = DatabaseHelper(this)

        databaseHelper.insertGuest(name,dob,gender,email,mobile,appointmentDate,appointmentTime)


        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }
}


