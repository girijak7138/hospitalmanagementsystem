package com.example.hospital;


// DatabaseHelper.java

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
        import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "user.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_TYPE = "type";


    public static final String TABLE_DOCTORS = "doctors";
    public static final String DOCTOR_COLUMN_ID = "_id";
    public static final String DOCTOR_COLUMN_NAME = "name";
    public static final String DOCTOR_COLUMN_DOB = "dob";
    public static final String DOCTOR_COLUMN_SEX = "sex";
    public static final String DOCTOR_COLUMN_SPECIALTY = "specialty";
    public static final String DOCTOR_COLUMN_MOBILE = "mobile";
    public static final String DOCTOR_COLUMN_EMAIL = "email";
    public static final String DOCTOR_COLUMN_PATIENT_IDS = "patientids";




    public static final String TABLE_PATIENTS = "patients";
    public static final String PATIENT_COLUMN_ID = "_id";
    public static final String PATIENT_COLUMN_NAME = "name";
    public static final String PATIENT_COLUMN_DISEASE = "disease";
    public static final String PATIENT_COLUMN_ROOM_NUMBER = "room_number";
    public static final String PATIENT_COLUMN_PHONE_NUMBER = "phone_number";
    public static final String PATIENT_COLUMN_ADDRESS = "address";

    public static final String TABLE_GUESTS = "guests";
    public static final String GUEST_COLUMN_ID = "_id";
    public static final String GUEST_COLUMN_NAME = "name";
    public static final String GUEST_COLUMN_DOB = "dob";
    public static final String GUEST_COLUMN_SEX = "sex";
    public static final String GUEST_COLUMN_MOBILE = "mobile";
    public static final String GUEST_COLUMN_EMAIL = "email";
    public static final String GUEST_COLUMN_DATE = "date";
    public static final String GUEST_COLUMN_TIME = "time";

    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT, " +
                    COLUMN_PASSWORD + " TEXT," + COLUMN_TYPE + " TEXT)";

    private static final String TABLE_DOCTORS_CREATE =
            "CREATE TABLE " + TABLE_DOCTORS + " (" +
                    DOCTOR_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    DOCTOR_COLUMN_NAME + " TEXT, " +
                    DOCTOR_COLUMN_DOB + " TEXT, " +
                    DOCTOR_COLUMN_SEX + " TEXT, " +
                    DOCTOR_COLUMN_SPECIALTY + " TEXT, " +
                    DOCTOR_COLUMN_EMAIL + " TEXT, " +
                    DOCTOR_COLUMN_PATIENT_IDS + " TEXT," +
                    DOCTOR_COLUMN_MOBILE + " TEXT)";

    private static final String TABLE_PATIENTS_CREATE =
            "CREATE TABLE " + TABLE_PATIENTS + " (" +
                    PATIENT_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    PATIENT_COLUMN_NAME + " TEXT, " +
                    PATIENT_COLUMN_DISEASE + " TEXT, " +
                    PATIENT_COLUMN_ROOM_NUMBER + " TEXT, " +
                    PATIENT_COLUMN_ADDRESS + " TEXT, " +
                    PATIENT_COLUMN_PHONE_NUMBER + " TEXT)";


    private static final String TABLE_GUESTS_CREATE =
            "CREATE TABLE " + TABLE_GUESTS + " (" +
                    GUEST_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    GUEST_COLUMN_NAME + " TEXT, " +
                    GUEST_COLUMN_DOB + " TEXT, " +
                    GUEST_COLUMN_SEX + " TEXT, " +
                    GUEST_COLUMN_EMAIL + " TEXT, " +
                    GUEST_COLUMN_MOBILE + " TEXT," +
                    GUEST_COLUMN_DATE + " TEXT, " +
                    GUEST_COLUMN_TIME + " TEXT)";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        db.execSQL(TABLE_DOCTORS_CREATE);
        db.execSQL(TABLE_PATIENTS_CREATE);
        db.execSQL(TABLE_GUESTS_CREATE);
//        insertDefaultAdminUser(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    public void insertDefaultAdminUser() {
        ContentValues values = new ContentValues();
        SQLiteDatabase db = getWritableDatabase();
        values.put(COLUMN_USERNAME, "girija");
        values.put(COLUMN_PASSWORD, "1234");
        values.put(COLUMN_TYPE, "admin");// Use a secure method for storing passwords in a real application
        db.insert(TABLE_USERS, null, values);
    }


    public void insertUser( String user,String password) {
        ContentValues values = new ContentValues();
        SQLiteDatabase db = getWritableDatabase();
        values.put(COLUMN_USERNAME,user );
        values.put(COLUMN_PASSWORD,password );
        values.put(COLUMN_TYPE, "doctor");// Use a secure method for storing passwords in a real application
        db.insert(TABLE_USERS, null, values);
    }


    public long insertDoctor(String name, String specialty, String mobile,String dob,String sex,String email) {
        ContentValues values = new ContentValues();
        SQLiteDatabase db = getWritableDatabase();
        values.put(DOCTOR_COLUMN_NAME, name);
        values.put(DOCTOR_COLUMN_SPECIALTY, specialty);
        values.put(DOCTOR_COLUMN_MOBILE, mobile);
        values.put(DOCTOR_COLUMN_DOB, dob);
        values.put(DOCTOR_COLUMN_SEX, sex);
        values.put(DOCTOR_COLUMN_EMAIL, email);
//        values.put(DOCTOR_COLUMN_PATIENT_IDS, patientIds);
        return db.insert(TABLE_DOCTORS, null, values);
    }

    public long insertPatient(String name, String disease, String roomNumber, String phoneNumber,String address) {
        ContentValues values = new ContentValues();
        SQLiteDatabase db = getWritableDatabase();
        values.put(PATIENT_COLUMN_NAME, name);
        values.put(PATIENT_COLUMN_DISEASE, disease);
        values.put(PATIENT_COLUMN_ROOM_NUMBER, roomNumber);
        values.put(PATIENT_COLUMN_PHONE_NUMBER, phoneNumber);
        values.put(PATIENT_COLUMN_ADDRESS, address);
        return db.insert(TABLE_PATIENTS, null, values);
    }

    public long insertGuest(String name, String dob, String sex,String mail,String mobile,String date,String time) {
        ContentValues values = new ContentValues();
        SQLiteDatabase db = getWritableDatabase();
        values.put(GUEST_COLUMN_NAME, name);
        values.put(GUEST_COLUMN_DOB, dob);
        values.put(GUEST_COLUMN_SEX, sex);
        values.put(GUEST_COLUMN_EMAIL, mail);
        values.put(GUEST_COLUMN_MOBILE, mobile);
        values.put(GUEST_COLUMN_DATE, date);
        values.put(GUEST_COLUMN_TIME, time);
        return db.insert(TABLE_GUESTS, null, values);
    }



    public void clearUsersTable() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_USERS, null, null);
    }


    public boolean authenticateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
//        insertDefaultAdminUser(db);
        Log.d("Database", "Authenticating user: " + username + ", password: " + password);

        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

//        Cursor cursor = db.query(
//                TABLE_USERS,
//                null,
//                selection,
//                selectionArgs,
//                null,
//                null,
//                null
//        );
//
//        int count = cursor.getCount();
//
//
//        Log.d("Database", "Number of rows in cursor: " +cursor.getColumnName(0) + count);
//
//        // Log the full data from the cursor
//        if (cursor.moveToFirst()) {
//            do {
//                for (int i = 0; i < cursor.getColumnCount(); i++) {
//                    String columnName = cursor.getColumnName(i);
//                    String columnValue = cursor.getString(i);
//                    Log.d("Database", columnName + ": " + columnValue);
//                }
//                Log.d("Database", "-----------------------");
//            } while (cursor.moveToNext());
//        }


        Cursor cursor = db.query(
                TABLE_USERS,
                null,
                null,
                null,
                null,
                null,
                null
        );

        // Log the full data from the cursor
        Log.d("Database", "Number cursor: " +cursor.moveToFirst()+cursor.getCount());
        if (cursor.moveToFirst()) {
            do {
                for (int i = 0; i < cursor.getColumnCount(); i++) {
                    String columnName = cursor.getColumnName(i);
                    String columnValue = cursor.getString(i);
                    Log.d("Database", columnName + ": " + columnValue);
                }
                Log.d("Database", "-----------------------");
            } while (cursor.moveToNext());
        }
        cursor.close();

        return true;
    }


}

