package com.example.hospital


import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class OutPatientActivity : AppCompatActivity() {

    private lateinit var patientsListView: ListView
//    private lateinit var createPatientButton: Button
//    private lateinit var backButton: Button
    private var dbHelper: DatabaseHelper? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.out_patient)

        patientsListView = findViewById(R.id.patientsListView)
//        createPatientButton = findViewById(R.id.createPatientButton)
//        backButton = findViewById(R.id.backButton)

        dbHelper = DatabaseHelper(this)


//        backButton.setOnClickListener {
//            val intent = Intent(this, DashboardActivity::class.java)
//            startActivity(intent)
//        }

        // Dummy data for doctors
        val patients = patientsList()


        // Set up an ArrayAdapter to display the dummy data in the ListView
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, patients)
        patientsListView.adapter = adapter





//        createDoctorButton.setOnClickListener(View.OnClickListener { login() })


//        createPatientButton.setOnClickListener {
//
//            val intent = Intent(this, PatientRegistrationActivity::class.java)
//            startActivity(intent)
//            // Launch CreateDoctorActivity
//            // You'll need to implement this activity separately for creating new doctors
////            val databaseHelper = DatabaseHelper(this)
////
////            databaseHelper.insertUser()
//        }


    }
    private fun patientsList(): MutableList<String> {



        val db = dbHelper!!.readableDatabase

        val PatientsNames = mutableListOf<String>()


        val cursor = db.query(
            DatabaseHelper.TABLE_GUESTS,
            null,  // columns (null selects all)
            null,  // selection
            null,  // selectionArgs
            null,  // groupBy
            null,  // having
            null // orderBy
        )
        val isValid = cursor.count > 0



        if (cursor.moveToFirst()) {
            do {
//

                val id = cursor.getLong(cursor.getColumnIndex(DatabaseHelper.PATIENT_COLUMN_ID))
                val name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.GUEST_COLUMN_NAME))
                val dob = cursor.getString(cursor.getColumnIndex(DatabaseHelper.GUEST_COLUMN_DOB))
                val sex = cursor.getString(cursor.getColumnIndex(DatabaseHelper.GUEST_COLUMN_SEX))
                val mobile = cursor.getString(cursor.getColumnIndex(DatabaseHelper.GUEST_COLUMN_MOBILE))
                val email = cursor.getString(cursor.getColumnIndex(DatabaseHelper.GUEST_COLUMN_EMAIL))
                val date = cursor.getString(cursor.getColumnIndex(DatabaseHelper.GUEST_COLUMN_DATE))
                val time = cursor.getString(cursor.getColumnIndex(DatabaseHelper.GUEST_COLUMN_TIME))


//                val doctorDetails = "ID: $id, Name: $name, DOB: $dob, Sex: $sex, Specialty: $specialty, Email: $email, Mobile: $mobile"
                val patientDetails = "\nID: $id\nName: $name\nDOB: $dob\nSex: $sex\nMobile: $mobile\nEmail: $email\nDateTime:$date $time"

                PatientsNames.add(patientDetails)

            } while (cursor.moveToNext())
        }else{
            PatientsNames.add("Out Patients not available")
        }
        return PatientsNames


        //Check credentials in the database


//        }
    }

}
