package com.example.hospital

// src/com/example/hospital/DoctorActivity.kt

import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DoctorActivity : AppCompatActivity() {

    private lateinit var doctorsListView: ListView
    private lateinit var createDoctorButton: Button
//    private lateinit var backButton: Button
    private var dbHelper: DatabaseHelper? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.doctor)

        doctorsListView = findViewById(R.id.doctorsListView)
        createDoctorButton = findViewById(R.id.createDoctorButton)
//        backButton = findViewById(R.id.backButton)
        dbHelper = DatabaseHelper(this)


//        backButton.setOnClickListener {
//            val intent = Intent(this, DashboardActivity::class.java)
//            startActivity(intent)
//        }

        // Dummy data for doctors
        val doctors = login()


        // Set up an ArrayAdapter to display the dummy data in the ListView
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, doctors)
        doctorsListView.adapter = adapter





//        createDoctorButton.setOnClickListener(View.OnClickListener { login() })


        createDoctorButton.setOnClickListener {

            val intent = Intent(this, DoctorRegistrationActivity::class.java)
            startActivity(intent)
            // Launch CreateDoctorActivity
            // You'll need to implement this activity separately for creating new doctors
//            val databaseHelper = DatabaseHelper(this)
//
//            databaseHelper.insertUser()
        }


    }
    private fun login(): MutableList<String> {



        val db = dbHelper!!.readableDatabase

        val doctorNames = mutableListOf<String>()


        val cursor = db.query(
            DatabaseHelper.TABLE_DOCTORS,
            null,  // columns (null selects all)
            null,  // selection
            null,  // selectionArgs
            null,  // groupBy
            null,  // having
            null // orderBy
        )
        val isValid = cursor.count > 0



        if (cursor.moveToFirst()) {
            do {
//

                val id = cursor.getLong(cursor.getColumnIndex(DatabaseHelper.DOCTOR_COLUMN_ID))
                val name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.DOCTOR_COLUMN_NAME))
                val dob = cursor.getString(cursor.getColumnIndex(DatabaseHelper.DOCTOR_COLUMN_DOB))
                val sex = cursor.getString(cursor.getColumnIndex(DatabaseHelper.DOCTOR_COLUMN_SEX))
                val specialty = cursor.getString(cursor.getColumnIndex(DatabaseHelper.DOCTOR_COLUMN_SPECIALTY))
                val email = cursor.getString(cursor.getColumnIndex(DatabaseHelper.DOCTOR_COLUMN_EMAIL))
                val mobile = cursor.getString(cursor.getColumnIndex(DatabaseHelper.DOCTOR_COLUMN_MOBILE))

//                val doctorDetails = "ID: $id, Name: $name, DOB: $dob, Sex: $sex, Specialty: $specialty, Email: $email, Mobile: $mobile"
                val doctorDetails = "\nID: $id\nName: $name\nDOB: $dob\nSex: $sex\nSpecialty: $specialty\nEmail: $email\nMobile: $mobile\n"

                doctorNames.add(doctorDetails)

            } while (cursor.moveToNext())
        }else{
            doctorNames.add("")
        }
    return doctorNames


        //Check credentials in the database


//        }
    }

}
