
// src/com/example/hospital/DoctorRegistrationActivity.kt
package com.example.hospital

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class DoctorRegistrationActivity : AppCompatActivity() {

    private lateinit var doctorNameEditText: EditText
    private lateinit var doctorDOBEditText: EditText
    private lateinit var doctorSexRadioGroup: RadioGroup
    private lateinit var doctorSpecialistEditText: EditText
    private lateinit var doctorMobileEditText: EditText
    private lateinit var doctorEmailEditText: EditText
    private lateinit var registerDoctorButton: Button
    private lateinit var backButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.doctorregister)

        doctorNameEditText = findViewById(R.id.doctorNameEditText)
        doctorDOBEditText = findViewById(R.id.doctorDOBEditText)
        doctorSexRadioGroup = findViewById(R.id.doctorSexRadioGroup)
        doctorSpecialistEditText = findViewById(R.id.doctorSpecialistEditText)
        doctorMobileEditText = findViewById(R.id.doctorMobileEditText)
        doctorEmailEditText = findViewById(R.id.doctorEmailEditText)
        registerDoctorButton = findViewById(R.id.registerDoctorButton)
        backButton = findViewById(R.id.backButton)

        backButton.setOnClickListener {
            val intent = Intent(this, DoctorActivity::class.java)
            startActivity(intent)
        }

        registerDoctorButton.setOnClickListener {
            // Validate and register doctor
            val name = doctorNameEditText.text.toString()
            val dob = doctorDOBEditText.text.toString()
            val sex = if (doctorSexRadioGroup.checkedRadioButtonId == R.id.maleRadioButton) "Male" else "Female"
            val specialist = doctorSpecialistEditText.text.toString()
            val mobile = doctorMobileEditText.text.toString()
            val email = doctorEmailEditText.text.toString()
            val databaseHelper = DatabaseHelper(this)

            databaseHelper.insertDoctor(name,specialist,mobile,dob,sex,email)
            databaseHelper.insertUser(name,dob)

            val intent = Intent(this, DoctorActivity::class.java)
            startActivity(intent)
            // Add code to insert the doctor details into the database
            // You would typically use the DatabaseHelper class here

            // After inserting, you might want to navigate to a DoctorListActivity or another screen
        }
    }
}
