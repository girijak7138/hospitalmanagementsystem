package com.example.hospital

import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Arrays


// MainActivity.java


class LoginActivity : AppCompatActivity() {
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var guestButton: Button
    private var dbHelper: DatabaseHelper? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)
        usernameEditText = findViewById(R.id.usernameEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)
        guestButton = findViewById(R.id.guestButton)
        dbHelper = DatabaseHelper(this)

        guestButton.setOnClickListener {

            val intent = Intent(this, AppointmentFormActivity::class.java)
            startActivity(intent)

        }



        loginButton.setOnClickListener(View.OnClickListener { login() })
    }


    private fun attemptLogin() {
        val username = usernameEditText.text.toString()
        val password = passwordEditText.text.toString()
        val databaseHelper = DatabaseHelper(this)

        if (databaseHelper.authenticateUser(username, password)) {
            // Successful login, navigate to the next screen
            val intent = Intent(this@LoginActivity, DashboardActivity::class.java)
            startActivity(intent)
        } else {
            // Invalid credentials, show an error message or handle accordingly
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
        }
    }

    private fun login() {
        val username = usernameEditText.text.toString()
        val password = passwordEditText.text.toString()

        val db = dbHelper!!.readableDatabase

        val cursor = db.query(
            DatabaseHelper.TABLE_USERS,
            null,  // columns (null selects all)
            null,  // selection
            null,  // selectionArgs
            null,  // groupBy
            null,  // having
            null // orderBy
        )
        val isValid = cursor.count > 0


        Log.d("YourTag", "isValid: " +cursor.getCount()  +  isValid);

        if (cursor.moveToFirst()) {
            do {
                for (i in 0 until cursor.columnCount) {
                    val columnName = cursor.getColumnName(i)
                    val columnValue = cursor.getString(i)
                    Log.d("Database", "$columnName: $columnValue")
                }
                Log.d("Database", "-----------------------")
            } while (cursor.moveToNext())
        }

        if(isValid){
            val navigation = isValidUser(username, password)
            if (navigation == 1) {
                // Redirect to the next activity (e.g., HomeActivity)
                val intent = Intent(this@LoginActivity, DashboardActivity::class.java)
                startActivity(intent)
                finish() // Close the login activity
            } else if( navigation == 2){
                val intent = Intent(this@LoginActivity, DoctorDashboardActivity::class.java)
                startActivity(intent)
                finish()
            }
            else {
                // Display an error message
                // You can also clear the password field or show a toast
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
            }
        }else{
            val databaseHelper = DatabaseHelper(this)

            databaseHelper.insertDefaultAdminUser()
        }

         //Check credentials in the database


//        val cursor: Cursor = getAllUsers()
//        Log.d("YourTag", "data cursor: " + cursor);
//        if (cursor != null) {
//            while (cursor.moveToNext()) {
//                val username =
//                    cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_USERNAME))
//                val password =
//                    cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_PASSWORD))
//                val type =
//                    cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TYPE))
//
//                // Do something with the data
//                Log.d("YourTag", "data user: " + username + password + cursor);
//
//                val intent = Intent(this@LoginActivity, DashboardActivity::class.java)
//            startActivity(intent)
//            finish()
//            }
//            cursor.close()
//        }
    }

    private fun getAllUsers(): Cursor {
        val db = dbHelper!!.readableDatabase
        return db.query(
            DatabaseHelper.TABLE_USERS,
            null,  // columns (null selects all)
            null,  // selection
            null,  // selectionArgs
            null,  // groupBy
            null,  // having
            null // orderBy
        )
    }

    private fun isValidUser(username: String, password: String): Int {
        val db = dbHelper!!.readableDatabase
//        dbHelper!!.clearUsersTable()
        val projection = arrayOf(DatabaseHelper.COLUMN_ID)
        val selection = DatabaseHelper.COLUMN_USERNAME + " = ? AND " +
                DatabaseHelper.COLUMN_PASSWORD + " = ?"
        val selectionArgs = arrayOf(username, password)
        Log.d("YourTag", "data user: " + Arrays.toString(selectionArgs));
        val cursor = db.query(
            DatabaseHelper.TABLE_USERS,
            null,
            selection,
            selectionArgs,
            null,
            null,
            null
        )

        var isValid = cursor.count

        if (cursor.moveToFirst()) {
            val savedUsername = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_USERNAME))
            val savedPassword = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_PASSWORD))
            val userType = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TYPE))

            Log.d("YourTag", "Username: $savedUsername, Password: $savedPassword, Type: $userType")
            if(userType == "admin".toString()){
                isValid = 1
            }else{
                isValid =2
            }
        }
//        val isValid = cursor.count > 0

        cursor.close()
        db.close()
        return isValid
    } // Additional methods can be added for user registration, password recovery, etc.
}
