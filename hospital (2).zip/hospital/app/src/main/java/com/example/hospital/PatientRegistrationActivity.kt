package com.example.hospital


// src/com/example/hospital/PatientRegistrationActivity.kt

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class PatientRegistrationActivity : AppCompatActivity() {

    private lateinit var patientNameEditText: EditText
    private lateinit var diseaseEditText: EditText
//    private lateinit var doctorSexRadioGroup: RadioGroup
    private lateinit var roomNoEditText: EditText
    private lateinit var patientMobileEditText: EditText
    private lateinit var patientAddressEditText: EditText
    private lateinit var registerPatientButton: Button
    private lateinit var backButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.patientregister)

        patientNameEditText = findViewById(R.id.patientNameEditText)
        diseaseEditText = findViewById(R.id.diseaseEditText)
//        doctorSexRadioGroup = findViewById(R.id.doctorSexRadioGroup)
        roomNoEditText = findViewById(R.id.roomNoEditText)
        patientMobileEditText = findViewById(R.id.patientMobileEditText)
        patientAddressEditText = findViewById(R.id.patientAddressEditText)
        registerPatientButton = findViewById(R.id.registerPatientButton)
        backButton = findViewById(R.id.backButton)

        backButton.setOnClickListener {
            val intent = Intent(this, PatientActivity::class.java)
            startActivity(intent)
        }

        registerPatientButton.setOnClickListener {
            // Validate and register doctor
            val name = patientNameEditText.text.toString()
            val disease = diseaseEditText.text.toString()
//            val sex = if (doctorSexRadioGroup.checkedRadioButtonId == R.id.maleRadioButton) "Male" else "Female"
            val room = roomNoEditText.text.toString()
            val mobile = patientMobileEditText.text.toString()
            val address = patientAddressEditText.text.toString()
            val databaseHelper = DatabaseHelper(this)

            databaseHelper.insertPatient(name,disease,room,mobile,address)
//            databaseHelper.insertUser(name,dob)

            val intent = Intent(this, PatientActivity::class.java)
            startActivity(intent)
            // Add code to insert the doctor details into the database
            // You would typically use the DatabaseHelper class here

            // After inserting, you might want to navigate to a DoctorListActivity or another screen
        }
    }
}
